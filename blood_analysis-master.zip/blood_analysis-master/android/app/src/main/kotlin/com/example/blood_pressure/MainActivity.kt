package com.example.blood_pressure

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
