import 'package:flutter/material.dart';
import 'screens/register_screen.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/analysis_history_screen.dart';
import 'screens/graph_screen.dart';
import 'screens/upload_analysis_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Blood Preasure App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/register',
      routes: {
        '/login': (context) => const LoginPage(),
        '/register': (context) => const RegisterPage(),
        '/dashboard': (context) => const HomePage(),
        '/analysis_history': (context) => const AnalysisHistoryScreen(),
        '/upload_analysis': (context) => const UploadAnalysis(),
        '/graph_analysis': (context) => const GraphScreen(),
        '/profile': (context) => const ProfileScreen()
      },
    );
  }
}