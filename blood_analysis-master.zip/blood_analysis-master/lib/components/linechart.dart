import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

class LineChartWidge extends StatelessWidget {
  final List<DateTime> dateParamCheck;
  final List<double> valueParamCheck;
  final String title;

  const LineChartWidge({
    required this.dateParamCheck,
    required this.valueParamCheck,
    required this.title,
    Key? key,
  }) : super(key: key);


    String formatValue(double value) {
    if (value >= 1000000) {
      return '${(value / 1000000).toStringAsFixed(0)}M';
    } else {
      return value.toStringAsFixed(1);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        const SizedBox(height: 20),
        Center(
          child: SizedBox(
            height: 300,
            width: 400,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(show: false),
                titlesData: FlTitlesData(
                  bottomTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 22,
                    getTextStyles: (value) => const TextStyle(
                      color: Color(0xff72719b),
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                    getTitles: (value) {
                      if (value.toInt() < dateParamCheck.length) {
                        return DateFormat('yy/MM').format(dateParamCheck[value.toInt()]);
                      } else {
                        return "YY/MM";
                      }
                    },
                    margin: 8,
                  ),
                  leftTitles: SideTitles(
                    showTitles: true,
                    getTextStyles: (value) => const TextStyle(
                      color: Color(0xff75729e),
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                    getTitles: (value) {
                      return formatValue(value);
                    },
                    reservedSize: 28,
                    margin: 12,
                  ),
                ),
                borderData: FlBorderData(show: true),
                lineBarsData: [
                  // Line for dateParamCheck and valueParamCheck
                  LineChartBarData(
                    spots: List.generate(
                      dateParamCheck.length,
                      (index) => FlSpot(
                        index.toDouble(),
                        valueParamCheck[index],
                      ),
                    ),
                    isCurved: true,
                    colors: [Colors.blue],
                    barWidth: 3,
                    belowBarData: BarAreaData(
                      show: true,
                      colors: [
                        const Color(0xffe0f2f1),
                        const Color(0xffb2dfdb),
                      ],
                    ),
                    dotData: FlDotData(show: false),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
