import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class DistributedBarChartWidget extends StatelessWidget {
  final List<DateTime> dateParamCheck;
  final List<double> valueParamCheck;

  const DistributedBarChartWidget({
    required this.dateParamCheck,
    required this.valueParamCheck,

    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Round each value to the nearest integer
    List<int> roundedValues = valueParamCheck.map((value) => value.round()).toList();

    // Calculate the frequency of each unique value
    Map<int, int> valueFrequency = {};
    roundedValues.forEach((value) {
      valueFrequency[value] = (valueFrequency[value] ?? 0) + 1;
    });

    // Calculate the total count of values
    int totalCount = roundedValues.length;

    // Convert the frequencies to percentages
    Map<int, double> valuePercentages = {};
    valueFrequency.forEach((value, frequency) {
      valuePercentages[value] = frequency / totalCount;
    });

    // Create bar chart data
    List<BarChartGroupData> barChartGroups = [];
    valuePercentages.forEach((value, percentage) {
      barChartGroups.add(
        BarChartGroupData(
          x: value,
          barRods: [
            BarChartRodData(
              y: percentage,
              colors: [Colors.blue],
            ),
          ],
        ),
      );
    });

    return AspectRatio(
      aspectRatio: 1.7,
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        color: Colors.white,
        child: BarChart(
          BarChartData(
            alignment: BarChartAlignment.spaceAround,
            maxY: 1,
            minY: 0,
            groupsSpace: 12,
            barTouchData: BarTouchData(enabled: false),
            titlesData: FlTitlesData(
              leftTitles: SideTitles(
                showTitles: true,
                getTextStyles: (value) => const TextStyle(color: Color(0xff7589a2), fontWeight: FontWeight.bold, fontSize: 14),
                margin: 20,
                reservedSize: 28,
                getTitles: (value) {
                  return '${(value * 100).toInt()}%';
                },
              ),
              bottomTitles: SideTitles(
                showTitles: true,
                getTextStyles: (value) => const TextStyle(color: Color(0xff7589a2), fontWeight: FontWeight.bold, fontSize: 14),
                margin: 20,
                getTitles: (value) {
                  return value.toString();
                },
              ),
            ),
            borderData: FlBorderData(
              show: false,
            ),
            barGroups: barChartGroups,
          ),
        ),
      ),
    );
  }
}
