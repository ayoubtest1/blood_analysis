import 'package:flutter/material.dart';

class SlideshowWidget extends StatelessWidget {
  final List<Map<String, dynamic>> slideshowItems;

  const SlideshowWidget({Key? key, required this.slideshowItems})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 240,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: slideshowItems.length,
        itemBuilder: (context, index) {
          final isOdd = index.isOdd;
          final cardColor = isOdd ? const Color(0xFF438BFD) : const Color(0xFF8042F6);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4.0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 0.4,
              child: Card(
                elevation: 0,
                color: cardColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 50,
                        height: 50,
                        child: Image.asset(
                          slideshowItems[index]['image'],
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        slideshowItems[index]['label'],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: Colors.white
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        slideshowItems[index]['price'],
                        style: const TextStyle(
                          fontSize: 14,
                          color: Color.fromRGBO(255, 255, 255, 0.8),
                        ),
                      ),
                     const SizedBox(height: 10), // Adjust spacing as needed
                      ElevatedButton(
                        onPressed: () {
                          // Handle button tap
                        },
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                            Colors.white, // Button background color set to white
                          ),
                        ),
                        child: const Text('Ask AI'),
                      ),
                      const SizedBox(
                          height:
                              10), 
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
