import 'dart:convert';
import 'package:blood_pressure/components/barchart.dart';
import 'package:blood_pressure/components/linechart.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class SingleParameterScreen extends StatelessWidget {
  final String name;

  const SingleParameterScreen({Key? key, required this.name}) : super(key: key);

  Future<Map<String, dynamic>> fetchData() async {
    try {
      final userId = await getUserId();
      final url = Uri.parse(
          'https://predoctor.cesoft.io/public/userarea/statedetailsapi.php?parametername=$name&iduserlog=$userId');

      final response = await http.get(
        url,
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        // Parse the JSON response
        Map<String, dynamic> jsonData = jsonDecode(response.body);

        // Convert 'dateparamcheck' and 'predicted_dates' to DateTime
        List<DateTime> dateParamCheck = (jsonData['dateparamcheck'] as List)
            .map((timestamp) => DateTime.parse(timestamp))
            .toList();
        List<DateTime> predictedDates = (jsonData['predicted_dates'] as List)
            .map((timestamp) => DateTime.parse(timestamp))
            .toList();

        // Convert 'valueparamcheck' and 'predicted_values' to double
        List<double> valueParamCheck = (jsonData['valueparamcheck'] as List)
            .map((value) => double.tryParse(value.toString().replaceAll(',', '')) ?? 0.0)
            .toList();
        List<double> predictedValues = (jsonData['predicted_values'] as List)
            .map((value) => double.tryParse(value.toString().replaceAll(',', '')) ?? 0.0)
            .toList();

        return {
          'dateparamcheck': dateParamCheck,
          'valueparamcheck': valueParamCheck,
          'predicted_dates': predictedDates,
          'predicted_values': predictedValues,
        };
      } else {
        throw Exception('Failed to fetch data');
      }
    } catch (error) {
      // ignore: avoid_print
      print('Error fetching data: $error');
      throw Exception('Failed to fetch data');
    }
  }

  Future<String> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId') ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(name),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError || snapshot.data == null) {
            return const Center(
              child: Text('Error fetching data. Please try again later.'),
            );
          } else {
            final data = snapshot.data!;
            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      'Trends for $name',
                      style: const TextStyle(
                        fontSize: 24.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16.0),
                    SizedBox(
                      height: 200,
                      child: LineChartWidge(
                        dateParamCheck: data['dateparamcheck'],
                        valueParamCheck: data['valueparamcheck'],
                        title: "Real Data for $name",
                      ),
                    ),
                    const SizedBox(height: 200.0),
                    SizedBox(
                      height: 200,
                      child: LineChartWidge(
                        dateParamCheck: data['predicted_dates'],
                        valueParamCheck: data['predicted_values'],
                        title: "Predicted Data for $name",
                      ),
                    ),
                    const SizedBox(height: 200.0,),
                    const Text("Distrubution Data: "),
                    const SizedBox(height: 16,),
                    SizedBox(
                      height: 200,
                      child: DistributedBarChartWidget(dateParamCheck: data['dateparamcheck'], valueParamCheck:data['valueparamcheck'] ),
                    )
                  ],
                ),
              ),
            );
          }
        },
      ),
    );
  }
}
