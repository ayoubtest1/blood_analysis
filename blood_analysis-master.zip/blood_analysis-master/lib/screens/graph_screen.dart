import 'dart:convert';
import 'package:blood_pressure/components/sm_line_chart.dart';
import 'package:blood_pressure/screens/single_graphs.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class GraphScreen extends StatefulWidget {
  const GraphScreen({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _GraphScreenState createState() => _GraphScreenState();
}

class _GraphScreenState extends State<GraphScreen> {
  late List<String> parameterNames = [];
  late List<List<int>> parameterValues = [];
  int _selectedIndex = 2;
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final userId = await getUserId();
      final response = await http.post(
        Uri.parse('https://predoctor.cesoft.io/public/userarea/stateapi.php'),
        body: json.encode({'iduserlog': userId}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        if (data.containsKey('data')) {
          data['data'].forEach((key, value) {
            parameterNames.add(key);
            List<int> parsedValues = [];
            if (value['values'] is List) {
              parsedValues = (value['values'] as List<dynamic>)
                  .map((e) {
                    if (e is int) {
                      return e;
                    } else if (e is double) {
                      return e.toInt();
                    } else if (e is String) {
                      try {
                        return int.parse(e);
                      } catch (_) {
                        try {
                          return double.parse(e).toInt();
                        } catch (_) {
                          return null;
                        }
                      }
                    }
                    throw FormatException("Invalid value type: $e");
                  })
                  .whereType<int>()
                  .toList();
            }
            parameterValues.add(parsedValues);
          });
        }
      } else {
        throw Exception('Failed to load data: ${response.statusCode}');
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Failed to load data: $error';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<String> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId') ?? '';
  }

  Future<void> sendParameterName(String parameterName) async {
    try {
      setState(() {
        _isLoading = true;
      });

      final response = await http.post(
        Uri.parse('https://predoctor.cesoft.io/public/userarea/askaiapi.php'),
        body: json.encode({'parametername': parameterName}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        // Save the response or process it as needed
        final responseData = json.decode(response.body);
        // Display the response in its own screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ResponseScreen(responseData: responseData),
          ),
        );
      } else {
        throw Exception(
            'Failed to send parameter name: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
      // Handle error as needed
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('Graph & States'),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop(); // Navigate back
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            onPressed: () {
              Navigator.pushNamed(
                  context, '/profile'); // Navigate to profile screen
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header with Blood Analysis text...
            Container(
              padding: const EdgeInsets.all(16.0),
              child: const Text(
                'Analysis Parameters',
                style: TextStyle(fontSize: 24.0),
              ),
            ),
            const SizedBox(height: 24),
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _errorMessage != null
                    ? Center(
                        child: Text(
                          _errorMessage!,
                          style: const TextStyle(color: Colors.red),
                        ),
                      )
                    : Column(
                        children: parameterNames.asMap().entries.map((entry) {
                          final parameterName = entry.value;
                          final parameterIndex = entry.key;
                          final parameterData =
                              parameterValues.length > parameterIndex
                                  ? parameterValues[parameterIndex]
                                  : null;
                          if (parameterData == null || parameterData.isEmpty) {
                            return const SizedBox.shrink();
                          }

                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => SingleParameterScreen(
                                    name: parameterName,
                                  ),
                                ),
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 8.0, horizontal: 16.0),
                              child: Container(
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 2,
                                      blurRadius: 5,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                padding: const EdgeInsets.all(16.0),
                                child: Row(
                                  children: [
                                    Expanded(
                                      flex: 3,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            parameterName,
                                            style: const TextStyle(
                                                fontSize: 16.0,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          const SizedBox(height: 8.0),
                                        ],
                                      ),
                                    ),
                                    // Add your line chart widget here...
                                    LineChartWidget(data: parameterData), 
                                    const SizedBox(
                                      width: 20,
                                    ),
                                    MouseRegion(
                                      cursor: SystemMouseCursors.click,
                                      child: Tooltip(
                                        message: 'Ask AI',
                                        child: GestureDetector(
                                          onTap: () {
                                            sendParameterName(parameterName);
                                          },
                                          child: const Icon(Icons.chat),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.upload),
            label: 'Upload',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Graph',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
          switch (index) {
            case 0:
              Navigator.pushNamed(context, '/dashboard');
              break;
            case 1:
              Navigator.pushNamed(context, '/upload_analysis');
              break;
            case 2:
              Navigator.pushNamed(context, '/graph_analysis');
              break;
            case 3:
              Navigator.pushNamed(context, '/profile');
              break;
          }
        },
        selectedItemColor: const Color(0xFF39B6F2), // Active color
        unselectedItemColor: const Color(0xFFC2C2C2), // Inactive color
      ),
    );
  }
}

class ResponseScreen extends StatelessWidget {
  final Map<String, dynamic> responseData;

  const ResponseScreen({Key? key, required this.responseData})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Response :'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0), // Add padding here
          child: SingleChildScrollView(
            child: Text(
              responseData['ai_response'].toString(),
            ),
          ),
        ),
      ),
    );
  }
}
