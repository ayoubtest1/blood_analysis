// ignore_for_file: use_build_context_synchronously
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class UploadAnalysis extends StatefulWidget {
  const UploadAnalysis({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _UploadAnalysisState createState() => _UploadAnalysisState();
}

class _UploadAnalysisState extends State<UploadAnalysis> {
  final List<File> _images = [];
  int _selectedIndex = 1;

  Future<String> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId') ?? '';
  }

  Future<void> _pickImagesFromGallery() async {
    final picker = ImagePicker();
    List<XFile>? pickedFiles =
        await picker.pickMultiImage(imageQuality: 50);

    setState(() {
      _images.addAll(pickedFiles.map((file) => File(file.path)).toList());
    });
  }

  Future<void> _takePicture() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);

    setState(() {
      if (pickedFile != null) {
        _images.add(File(pickedFile.path));
      } else {
        // ignore: avoid_print
        print('No image selected.');
      }
    });
  }

  Future<void> _submit() async {
    try {
      // Show loading indicator
      showDialog(
        context: context,
        barrierDismissible: false, // Prevent dialog from being dismissed by tapping outside
        builder: (context) => const Center(child: CircularProgressIndicator()),
      );

      // Prepare the request body
      var baseUrl = 'https://predoctor.cesoft.io/public/userarea/pdfbloodscrape/upload_api.php';
      var userId = await getUserId();
      var url = Uri.parse('$baseUrl?userid=$userId');

    // Prepare the request body
    var request = http.MultipartRequest('POST', url);

      // Attach files to the request
      for (var image in _images) {
        request.files.add(
          await http.MultipartFile.fromPath('files[]', image.path),
        );
      }

      // Send the request
      var response = await request.send();

      // Handle the response
      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Uploaded Successfully')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Upload failed')),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $error')),
      );
    } finally {
      // Hide loading indicator
      Navigator.of(context).pop(); // Dismiss the dialog
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Upload Analysis'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _images.isEmpty
                ? const Text('No image selected.')
                : Text('${_images.length} selected'), // Use ! to assert non-nullability
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF438BFD), Color(0xFF8042F6)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: ElevatedButton(
                  onPressed: _pickImagesFromGallery,
                  style: ElevatedButton.styleFrom(
                    textStyle: const TextStyle(fontSize: 20),
                    elevation: 0, // Remove elevation from the button
                    padding: const EdgeInsets.all(12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    backgroundColor: Colors.transparent, // Make the button background transparent
                  ),
                  child: const SizedBox(
                    width: double.infinity, // Make the button take up the full width
                    child: Text(
                      'Select Images',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white), // Set text color to white
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 25,),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF438BFD), Color(0xFF8042F6)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: ElevatedButton(
                  onPressed: _takePicture,
                  style: ElevatedButton.styleFrom(
                    textStyle: const TextStyle(fontSize: 20),
                    elevation: 0, // Remove elevation from the button
                    padding: const EdgeInsets.all(12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    backgroundColor: Colors.transparent, // Make the button background transparent
                  ),
                  child: const SizedBox(
                    width: double.infinity, // Make the button take up the full width
                    child: Text(
                      'Take Picture',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white), // Set text color to white
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 25),
            if (_images.isNotEmpty)
             Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF438BFD), Color(0xFF8042F6)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: ElevatedButton(
                  onPressed: _submit,
                  style: ElevatedButton.styleFrom(
                    textStyle: const TextStyle(fontSize: 20),
                    elevation: 0, // Remove elevation from the button
                    padding: const EdgeInsets.all(12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    backgroundColor: Colors.transparent, // Make the button background transparent
                  ),
                  child: const SizedBox(
                    width: double.infinity, // Make the button take up the full width
                    child: Text(
                      'Upload Analysis',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white), // Set text color to white
                    ),
                  ),
                ),
              ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.upload),
            label: 'Upload',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Graph',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
          switch (index) {
            case 0:
              Navigator.pushNamed(context, '/dashboard');
              break;
            case 1:
              Navigator.pushNamed(context, '/upload_analysis');
              break;
            case 2:
              Navigator.pushNamed(context, '/graph_analysis');
              break;
            case 3:
              Navigator.pushNamed(context, '/profile');
              break;
          }
        },
        selectedItemColor: const Color(0xFF39B6F2), // Active color
        unselectedItemColor: const Color(0xFFC2C2C2), // Inactive color
      ),
    );
  }
}
