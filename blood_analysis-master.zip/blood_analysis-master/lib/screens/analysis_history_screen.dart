import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AnalysisHistoryScreen extends StatefulWidget {
  const AnalysisHistoryScreen({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _AnalysisHistoryScreenState createState() => _AnalysisHistoryScreenState();
}

class _AnalysisHistoryScreenState extends State<AnalysisHistoryScreen> {
  late Future<List<Document>> futureDocuments;
  String? userId;

  @override
  void initState() {
    super.initState();
    futureDocuments = fetchData();
  }

  Future<List<Document>> fetchData() async {
    try {
      userId = await getUserId();

      final response = await http.post(
        Uri.parse('https://predoctor.cesoft.io/public/userarea/youranalysisapi.php'),
        body: jsonEncode(<String, String>{
          'iduserlog': userId!,
        }),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        if (responseData is List) {
          return responseData
              .map((data) => Document(
                    name: data['reportsNumberLab'] != null && data['reportsNumberLab'].isNotEmpty
                        ? data['reportsNumberLab']
                        : data['idreports'],
                    date: data['reportDateIn'],
                    test: "Esami del Sangue",
                    status: "Completed",
                  ))
              .toList();
        } else {
          throw Exception('Invalid response data format: $responseData');
        }
      } else {
        throw Exception('Failed to fetch data: ${response.statusCode}');
      }
    } catch (error) {
      throw Exception('Error fetching data: $error');
    }
  }

  Future<String> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId') ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('Blood Analysis'),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop(); // Navigate back
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            onPressed: () {
              Navigator.pushNamed(context, '/profile'); // Navigate to profile screen
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Document>>(
        future: futureDocuments,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 20),
                  Text(
                    'Fetching data...',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            );
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final documents = snapshot.data!;
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16.0),
                    child: const Text(
                      'Statistics',
                      style: TextStyle(fontSize: 24.0),
                    ),
                  ),
                  // Circle with gradient background and two flexed items
                  Container(
                    width: 250,
                    height: 250,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFF39B6F2), Color(0xFF8042F6)],
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Documents
                        const Text(
                          'Documents',
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                        Text(
                          '${documents.length}',
                          style: const TextStyle(fontSize: 34, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Document boxes
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: documents.map((document) {
                      Color statusColor;
                      switch (document.status) {
                        case 'Completed':
                          statusColor = Colors.green;
                          break;
                        case 'Pending':
                          statusColor = Colors.yellow;
                          break;
                        case 'Error':
                        default:
                          statusColor = Colors.red;
                      }

                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10.0),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.grey,
                                spreadRadius: 2,
                                blurRadius: 5,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Document : ${document.name}',
                                style: const TextStyle(
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8.0),
                              Text(
                                'Analysis: ${document.test}',
                                style: const TextStyle(fontSize: 14.0),
                              ),
                              const SizedBox(height: 8.0),
                              Text(
                                'Date: ${document.date}',
                                style: const TextStyle(fontSize: 14.0),
                              ),
                              const SizedBox(height: 8.0),
                              Row(
                                children: [
                                  const Text(
                                    'Status: ',
                                    style: TextStyle(fontSize: 14.0),
                                  ),
                                  Text(
                                    document.status,
                                    style: TextStyle(
                                      fontSize: 14.0,
                                      color: statusColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                       ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}

class Document {
  final String name;
  final String test;
  final String date;
  final String status;

  Document({
    required this.name,
    required this.test,
    required this.date,
    required this.status,
  });
}
